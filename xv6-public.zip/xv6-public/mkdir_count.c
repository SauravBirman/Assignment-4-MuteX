#include "types.h"
#include "user.h"

int main(){
	printf(2,"Counts of mkdir=%d\n",mkdir_count());
	exit();
}
