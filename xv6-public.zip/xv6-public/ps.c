#include "types.h"
#include "stat.h"
#include "user.h"


int main() {
printf(2,"PID	NAME	STATUS  \n") ;
ps() ; 
exit() ;
} 
